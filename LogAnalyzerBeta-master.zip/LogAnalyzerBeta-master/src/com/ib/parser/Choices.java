package com.ib.parser;

public class Choices {
	public final static int LOGINSEQ = 1;
	public final static int SYSRES = 2;
	public final static int ENV = 3;
	public final static int CONN = 4;
	public final static int ORDERSTRDS = 5;
	public final static int MKTDATA = 6;
	public final static int API = 7;
	public final static int HTBP = 9;
}
