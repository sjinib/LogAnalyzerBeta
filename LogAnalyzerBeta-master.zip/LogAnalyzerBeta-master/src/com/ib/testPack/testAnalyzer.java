package com.ib.testPack;

import com.ib.manager.*;

public class testAnalyzer {
	public static void main(String [] arg){
		LogManager manager = new LogManager();
		//manager.start();
	}
}
