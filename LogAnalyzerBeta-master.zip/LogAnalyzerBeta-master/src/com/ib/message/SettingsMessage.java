package com.ib.message;

public class SettingsMessage {

}
